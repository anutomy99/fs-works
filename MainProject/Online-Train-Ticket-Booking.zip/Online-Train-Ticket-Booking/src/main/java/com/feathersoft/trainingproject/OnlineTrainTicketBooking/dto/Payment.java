package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

public class Payment {
}
