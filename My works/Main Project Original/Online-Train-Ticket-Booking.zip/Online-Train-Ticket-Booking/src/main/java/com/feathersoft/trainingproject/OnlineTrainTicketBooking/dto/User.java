package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;

import java.util.List;

@Entity
@Data
@JsonIgnoreProperties({"id","bookingDetails"})
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank
    @NotNull
    private String name;

  
    @NotNull
    private Integer age;

    @NotBlank
    private String gender;

    @NotBlank
    @NotEmpty
    @Email
    @Pattern(regexp = "^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,}$",message = "Enter a valid email address")
    @Column(name = "Email",unique = true)
    private String email;


    @NotBlank(message = "mobile number is required")
    @Size(min = 10, max = 10)
    @Column(name = "Phone",unique = true)
    private String phone;

    @JsonIgnore
    private String password;

    @NotBlank
    @JsonIgnore
    private String role;

    @Column(name = "Image",length = 16777216)
    private byte[] profileImage;


    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
    private List<BookingDetails> bookingDetails;

    @JsonIgnore
    @OneToMany(mappedBy = "user",cascade = CascadeType.ALL)
    private List<Token> tokens;

}
