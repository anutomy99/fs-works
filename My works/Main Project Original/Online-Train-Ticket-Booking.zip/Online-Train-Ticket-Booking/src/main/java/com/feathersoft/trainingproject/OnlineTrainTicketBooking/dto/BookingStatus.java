package com.feathersoft.trainingproject.OnlineTrainTicketBooking.dto;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
